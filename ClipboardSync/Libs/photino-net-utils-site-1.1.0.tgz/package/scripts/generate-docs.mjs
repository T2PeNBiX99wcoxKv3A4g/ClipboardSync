// Builds `src/docs.generated.ts` from the markdown in `Site/docs`, in every language the site offers.
//
// Each language has its own folder (`docs/en`, `docs/ja`, ...) with the same page names, so a page is
// `docs/<language>/<page>.md`. A missing translation falls back to English. The pages and languages
// come from the project's `site.config.mjs`, so this script has no project-specific values.
//
// A page may name a `source` instead of keeping a copy of the file under `docs`, which is how a
// changelog already written at the root of the repository becomes a page without being copied:
//
//   docs: [{slug: "Changelog", group: "history", source: "../CHANGELOG.md", remote: "master/CHANGELOG.md"}]
//
// A translation still wins over that source, and the body is stored once when every language reuses
// it, so a long changelog does not travel four times. `remote` is the address the page reads the
// latest file from at runtime, so a site built before the file changed still shows the newest text;
// the generated body is what a failed request leaves on screen.
//
// Run from the site directory: `node node_modules/@photino-net-utils/site/scripts/generate-docs.mjs`.

import {existsSync} from "node:fs";
import {readFile, writeFile} from "node:fs/promises";
import path from "node:path";

const siteRoot = process.cwd();
const configPath = path.join(siteRoot, "site.config.mjs");

if (!existsSync(configPath)) {
    throw new Error(`No site.config.mjs in ${siteRoot}; the docs generator reads the page list from it.`);
}

const {site} = await import(`file://${configPath.replace(/\\/g, "/")}?v=${Date.now()}`);
const pages = site.docs ?? [];
const languages = site.languages ?? ["en"];

const known = new Set(pages.map((page) => page.slug));

/** Links point at page names; on the site they become hash routes. */
function rewriteLinks(body) {
    return body.replace(/\]\(([^)\s]+)\)/g, (match, target) => {
        const page = target.split("#")[0];
        return known.has(page) ? `](#/docs/${page})` : match;
    });
}

/** The page title is its first heading, which is translated along with the rest of the text. */
function titleOf(body, fallback) {
    const match = /^#\s+(.+)$/m.exec(body);
    return match ? match[1].trim() : fallback;
}

/** A file a page is built from, read once even when several languages share it. */
const files = new Map();

async function bodyOf(page, language) {
    const candidates = [
        path.join(siteRoot, "docs", language, `${page.slug}.md`),
        ...(page.source ? [path.resolve(siteRoot, page.source)] : []),
        path.join(siteRoot, "docs", "en", `${page.slug}.md`),
    ];

    const file = candidates.find((candidate) => existsSync(candidate));
    if (!file) {
        throw new Error(`No markdown for "${page.slug}" (${language}); write ${candidates[0]} first.`);
    }

    if (!files.has(file)) {
        files.set(file, rewriteLinks((await readFile(file, "utf8")).trim()));
    }

    return {file, body: files.get(file)};
}

/**
 * The address the page reads at runtime: a path inside the repository becomes the raw file, a full
 * URL is taken as it is, and a page without one keeps only the generated body.
 */
function remoteUrl(page) {
    if (!page.remote) return undefined;
    if (/^https?:\/\//i.test(page.remote)) return page.remote;

    const raw = site.repository
        .replace("https://github.com/", "https://raw.githubusercontent.com/")
        .replace(/\/$/, "");

    return `${raw}/${page.remote.replace(/^\//, "")}`;
}

const docs = {};

for (const language of languages) {
    const entries = [];

    for (const page of pages) {
        const {file, body} = await bodyOf(page, language);

        // A translation is what its readers came for, so a page taken from the source file is the
        // only one that goes looking for a newer copy.
        const source = page.source ? path.resolve(siteRoot, page.source) : "";

        entries.push({
            slug: page.slug,
            group: page.group,
            title: titleOf(body, page.slug.replace(/-/g, " ")),
            body,
            remote: file === source ? remoteUrl(page) : undefined,
            file,
        });
    }

    docs[language] = entries;
}

/** A body more than one language reads is stored once and referenced from each of them. */
const uses = new Map();
for (const entries of Object.values(docs)) {
    for (const entry of entries) uses.set(entry.file, (uses.get(entry.file) ?? 0) + 1);
}

/** Entries whose body several languages share; a translation is stored on its own. */
const isShared = (entry) => uses.get(entry.file) > 1;

const shared = new Map();
for (const entries of Object.values(docs)) {
    for (const entry of entries) if (isShared(entry)) shared.set(entry.slug, entry.body);
}

const literal = (value) => JSON.stringify(value);

const body = Object.entries(docs)
    .map(([language, entries]) => {
        const items = entries
            .map((entry) => `        {\n            slug: ${literal(entry.slug)},\n            group: ${literal(entry.group)},\n` +
                `            title: ${literal(entry.title)},\n` +
                `            body: ${isShared(entry) ? `shared[${literal(entry.slug)}]` : literal(entry.body)},\n` +
                (entry.remote ? `            remote: ${literal(entry.remote)},\n` : "") + `        },`)
            .join("\n");

        return `    ${literal(language)}: [\n${items}\n    ],`;
    })
    .join("\n");

/** Declared only when a body is reused; an empty one would be an unused local in a strict build. */
const sharedDeclaration = shared.size === 0
    ? ""
    : `const shared: Record<string, string> = {\n${[...shared]
        .map(([slug, text]) => `    ${literal(slug)}: ${literal(text)},`)
        .join("\n")}\n};\n\n`;

await writeFile(
    path.join(siteRoot, "src", "docs.generated.ts"),
    `/**
 * Generated by \`npm run generate\` — do not edit by hand.
 *
 * The documentation pages, one entry per page and language, read from \`docs/<language>/<page>.md\`
 * or from the \`source\` file a page names. Bodies every language reuses are kept once, below.
 */
export interface GeneratedDoc {
    slug: string;
    group: string;
    title: string;
    body: string;
    remote?: string;
}

${sharedDeclaration}export const docs: Record<string, GeneratedDoc[]> = {
${body}
};
`,
    "utf8",
);

console.log(`Wrote ${pages.length} page(s) in ${languages.length} language(s) to src/docs.generated.ts`);
